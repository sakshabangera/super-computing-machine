<html>
    <head>
        <title>CRYPTO SITE</title>
        <link rel="stylesheet" href="style1.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="banner">              
            <div class="navbar">
                     <img src="lg.png" class="logo">
                     <a href="#contact">Contact</a>
                    
                     <!--<div class="dropdown">
                        <button class="dropbtn">Login
                          <i class="fa fa-caret-down"></i>
                        </button>
                        <div class="dropdown-content">
                          <a href="http://localhost/Project/examinerLogin.php">Examiner</a>
                          <a href="http://localhost/Project/candidateLogin.php">Candidate</a>
                          <a href="http://localhost/Project/adminLogin.php">Administrator</a>
                        </div>
                      </div> -->
                      <a href="http://localhost/Project/examinerLogin.php">Login</a>
                        <a href="index.php">Home</a>
                    </div>
            
            <div class="content">
                <h1>CRYPTO PORTAL</h1>
                <p>Trust Yourself.<br> You know more than you think you do.</p>
          </div>
        </div>
          </div>
          <div id="contact" class="footer">
            <br>
            <h2>CONTACT US AT</h2>
            <br>
            <i class="fa fa-address-book" style="font-size:25px">  +91 9879535618</i>
            <br>
            <i class="fa fa-envelope" style="font-size:25px">  admin@gmail.com</i>

        </div>
    </body>
    
</html>

